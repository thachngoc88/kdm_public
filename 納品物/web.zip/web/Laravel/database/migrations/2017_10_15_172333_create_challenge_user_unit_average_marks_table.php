<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChallengeUserUnitAverageMarksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('challenge_user_unit_average_marks', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('mark');
            $table->integer('unit_id')->unsigned();
            $table->integer('challenge_user_id')->unsigned();
            $table->integer('marking_log_id')->unsigned();
            $table->softDeletes();
            $table->timestamps();
            $table->foreign('unit_id')->references('id')->on('units');
            $table->foreign('challenge_user_id')->references('id')->on('challenge_users');
            $table->foreign('marking_log_id')->references('id')->on('marking_logs');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        Schema::dropIfExists('challenge_user_unit_average_marks');
        //DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
