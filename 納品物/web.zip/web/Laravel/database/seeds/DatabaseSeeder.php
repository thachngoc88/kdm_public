<?php

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        $this->call(UsersSeeder::class);
        $this->call(SubjectsSeeder::class);
        $this->call(GradesSeeder::class);
        $this->call(CurriculumsSeeder::class);
        $this->call(PrefecturesSeeder::class);
        $this->call(CitiesSeeder::class);
        $this->call(SchoolsSeeder::class);
        $this->call(ClassesSeeder::class);
        $this->call(UnitsSeeder::class);
        $this->call(WorkbooksSeeder::class);
        $this->call(ChallengesSeeder::class);
        $this->call(QuestionsSeeder::class);
        $this->call(AnswersSeeder::class);
        $this->call(RecordsSeeder::class);
        $this->call(TimingsSeeder::class);
        $this->call(ConditionsSeeder::class);
        $this->call(MessagesSeeder::class);
//        $this->call(MakingLogsSeeder::class);
//        $this->call(MarksSeeder::class);
//        $this->call(ChallengeUserUnitStatusSeeder::class);
//        $this->call(ChallengeUserWorkbookStatusSeeder::class);
        $this->call(SupplementsSeeder::class);
        $this->call(ChallengeQuestionSupplementSeeder::class);
//        $this->call(ExistingPdfSeeder::class);
//        $this->call(ClassUnitPassingRatesSeeder::class);
//        $this->call(ClassPassingRatesSeeder::class);
//        $this->call(ClassCurriculumPassingRatesSeeder::class);
//        $this->call(SchoolPassingRatesSeeder::class);
//        $this->call(SchoolUnitPassingRatesSeeder::class);
//        $this->call(SchoolCurriculumPassingRatesSeeder::class);
//        $this->call(CityPassingRatesSeeder::class);
//        $this->call(CityUnitPassingRatesSeeder::class);
//        $this->call(CityCurriculumPassingRatesSeeder::class);
        Model::reguard();
    }
}
