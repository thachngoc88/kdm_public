<?php

use App\Klass;
use App\User;
use Illuminate\Support\Facades\Hash;
class ClassesSeeder extends CommonSeeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //delete all data.
        //DB::statement('SET CONSTRAINTS ALL DEFERRED;');
//        Klass::truncate();
        //DB::statement('SET CONSTRAINTS ALL IMMEDIATE;');
        //
        $faker = Faker\Factory::create("ja_JP");

        $schools = \App\School::all('id');
       foreach ($schools as $school){
            for ($g = 4; $g <= 4; $g++){
                $mc = 2;
                for ($c = 1; $c <= $mc; $c++) {
                    $class = Klass::create([
                        "name" => $c,
                        "school_id" => $school->id,
                        "grade_id" => $g - 3,
                    ]);
                    $class->save();

                    for ($u = 0; $u < 45; $u++) { // 45 in 1 class
                        $uu = (($g - 4) * $mc * 45) + (($c - 1) * 45) + $u;
                        $userId = $uu + 21 + (($school->id - 1) * 90); // max 90 in 1 school
                        \App\ChallengeUser::create([
                            "user_id"  => $userId,
                            "class_id" => $class->id,
                            "order"    => $u,
                        ])->save();

                        $user = User::find($userId);
                        $user->login_id = $this->createLoginId($user);
                        $password = $this->createPass($user);
                        $user->password = Hash::make($password);
                        echo("id {$user->id}" . PHP_EOL);
                        echo("login_id {$user->login_id}" . PHP_EOL);
                        echo("password {$password}" . PHP_EOL);
                        $user->save();
                    }
                }
            }
        }
    }
    private function createLoginId(User $user){
       if(array_key_exists($user->id, $this->userClass()))
        {
            //echo("login_id have: {$this->userClass()[$user->id][0]}" . PHP_EOL);
            return $this->userClass()[$user->id][0];

        }
        $nameClass = $user->classes[0]->name;
        $nameGrade = $user->classes[0]->grade->number;
        $codeScholl = $user->classes[0]->school->code;
        $valid_fourDigit = "23456789";
        $valid_alphabetic ="abcdefghijkmnpqrstuvwxyz";
        do {
            $fourDigit = $this->randChars($valid_fourDigit, 4);
            $alphabetic = $this->randChars($valid_alphabetic, 1);
            $result = $codeScholl . '-' . $nameGrade . $nameClass . '-' . $fourDigit . $alphabetic;

            $input = array('login_id' => $result);
            $validator = Validator::make(array_filter($input), [
                'login_id' => 'unique:users,login_id'
            ]);
        }
        while($validator->fails());

        return $result;
    }
    private function createPass(User $user){

        if(array_key_exists($user->id, $this->userClass()))
        {
            //echo("password have: {$this->userClass()[$user->id][1]}" . PHP_EOL);
            return $this->userClass()[$user->id][1];

        }
        //
        $valid_Pass = "23456789abcdefghijkmnpqrstuvwxyz";
        $passUpdate = $this->randChars($valid_Pass, 4);

        return $passUpdate;
    }
    private function userClass(){
        return [
            21=>['a1-01w','nrz2'],
            22=>['a1-02p','8dyr'],
            23=>['a1-03h','885t'],
            24=>['a1-04z','bn6z'],
            25=>['a1-05b','mm25'],
            26=>['a1-06u','mynn'],
            27=>['a1-07m','xrwy'],
            28=>['a1-08a','pcwk'],
            29=>['a1-09x','b4nc'],
            30=>['a1-10w','b55n'],
            31=>['a1-11r','d7ue'],
            32=>['a1-12n','2ymu'],
            33=>['a1-13p','5c8w'],
            34=>['a1-14f','ftba'],
            35=>['a1-15f','3tjk'],
            36=>['a1-16p','878n'],
            37=>['a1-17k','7kn2'],
            38=>['a1-18b','vsb5'],
            39=>['a1-19z','vi73'],
            40=>['a1-20s','842d'],
            41=>['a1-21m','3bmk'],
            42=>['a1-22s','62k7'],
            43=>['a1-23n','it7r'],
            44=>['a1-24j','5yjt'],
            45=>['a1-25f','jh7v'],
            46=>['a1-26a','mmew'],
            47=>['a1-27t','nfex'],
            48=>['a1-28t','wdxt'],
            49=>['a1-29v','bvzs'],
            50=>['a1-30m','tb2c'],
            51=>['a1-31b','r7er'],
            52=>['a1-32u','nimh'],
            53=>['a1-33f','54p7'],
            54=>['a1-34f','rmud'],
            55=>['a1-35k','an73'],
            56=>['a1-36u','ewxs'],
            57=>['a1-37m','eh4d'],
            58=>['a1-38j','zepm'],
            59=>['a1-39u','8wfm'],
            60=>['a1-40z','j7xh'],
            61=>['a1-41v','345i'],
            62=>['a1-42c','dpm5'],
            63=>['a1-43p','8nhb'],
            64=>['a1-44e','hzxu'],
            65=>['a1-45c','xsy5'],
            66=>['a2-01e','dcdm'],
            67=>['a2-02c','xewu'],
            68=>['a2-03x','3isv'],
            69=>['a2-04j','zht2'],
            70=>['a2-05h','467n'],
            71=>['a2-06c','hb7h'],
            72=>['a2-07h','dkc2'],
            73=>['a2-08e','5aum'],
            74=>['a2-09i','hyw5'],
            75=>['a2-10i','s4w6'],
            76=>['a2-11z','pum3'],
            77=>['a2-12e','yh8n'],
            78=>['a2-13s','435j'],
            79=>['a2-14c','7i4i'],
            80=>['a2-15x','mwkh'],
            81=>['a2-16i','mzup'],
            82=>['a2-17a','zxy6'],
            83=>['a2-18p','jzbv'],
            84=>['a2-19z','nc7y'],
            85=>['a2-20v','6tyt'],
            86=>['a2-21c','anpx'],
            87=>['a2-22h','pusv'],
            88=>['a2-23h','xkfm'],
            89=>['a2-24j','icyv'],
            90=>['a2-25u','eben'],
            91=>['a2-26v','bzd4'],
            92=>['a2-27c','e6f8'],
            93=>['a2-28r','7zac'],
            94=>['a2-29p','6mih'],
            95=>['a2-30t','6hrm'],
            96=>['a2-31h','2ver'],
            97=>['a2-32w','jtek'],
            98=>['a2-33d','skvc'],
            99=>['a2-34s','7te4'],
            100=>['a2-35m','tit4'],
            101=>['a2-36k','68nx'],
            102=>['a2-37b','mfi6'],
            103=>['a2-38y','2h7j'],
            104=>['a2-39b','tnbh'],
            105=>['a2-40w','nme8'],
            106=>['a2-41p','ibdt'],
            107=>['a2-42i','37ns'],
            108=>['a2-43i','fuy8'],
            109=>['a2-44a','wvmh'],
            110=>['a2-45z','m2ev'],
            111=>['b1-01z','3jck'],
            112=>['b1-02d','4n53'],
            113=>['b1-03h','aity'],
            114=>['b1-04i','hzwt'],
            115=>['b1-05v','vrw6'],
            116=>['b1-06s','u7fh'],
            117=>['b1-07c','45jv'],
            118=>['b1-08p','xhst'],
            119=>['b1-09t','syx7'],
            120=>['b1-10t','6ck2'],
            121=>['b1-11c','j34b'],
            122=>['b1-12d','5rky'],
            123=>['b1-13n','ea5f'],
            124=>['b1-14j','88ef'],
            125=>['b1-15m','rfsx'],
            126=>['b1-16n','ada4'],
            127=>['b1-17n','xn53'],
            128=>['b1-18j','jy6w'],
            129=>['b1-19x','n7tw'],
            130=>['b1-20v','ws48'],
            131=>['b1-21h','yd4d'],
            132=>['b1-22r','83k5'],
            133=>['b1-23a','8b2d'],
            134=>['b1-24b','jv87'],
            135=>['b1-25f','br5a'],
            136=>['b1-26b','zx48'],
            137=>['b1-27y','f4ua'],
            138=>['b1-28k','45nc'],
            139=>['b1-29b','tvjd'],
            140=>['b1-30m','2ipc'],
            141=>['b1-31w','vviv'],
            142=>['b1-32z','6kn5'],
            143=>['b1-33e','fyrb'],
            144=>['b1-34z','ivzh'],
            145=>['b1-35c','4zxj'],
            146=>['b1-36t','2wtm'],
            147=>['b1-37n','cm3v'],
            148=>['b1-38e','t35p'],
            149=>['b1-39d','mupe'],
            150=>['b1-40j','kxh8'],
            151=>['b1-41v','6ut4'],
            152=>['b1-42b','vpei'],
            153=>['b1-43v','48xt'],
            154=>['b1-44h','f4uv'],
            155=>['b1-45u','nh4u'],
            156=>['b2-01e','uz3s'],
            157=>['b2-02f','nt2u'],
            158=>['b2-03n','pbxw'],
            159=>['b2-04u','28w5'],
            160=>['b2-05b','xp56'],
            161=>['b2-06a','6nss'],
            162=>['b2-07r','ubze'],
            163=>['b2-08a','6r4h'],
            164=>['b2-09s','kvse'],
            165=>['b2-10x','y6wj'],
            166=>['b2-11p','d2ai'],
            167=>['b2-12i','ybr6'],
            168=>['b2-13s','hi6r'],
            169=>['b2-14d','mi5y'],
            170=>['b2-15v','drj5'],
            171=>['b2-16a','cr37'],
            172=>['b2-17f','ymwd'],
            173=>['b2-18b','xaii'],
            174=>['b2-19w','ta5f'],
            175=>['b2-20a','jd27'],
            176=>['b2-21u','7dz7'],
            177=>['b2-22a','38ee'],
            178=>['b2-23w','m7x6'],
            179=>['b2-24e','nmze'],
            180=>['b2-25s','piym'],
            181=>['b2-26p','ueun'],
            182=>['b2-27a','2ia4'],
            183=>['b2-28m','36yc'],
            184=>['b2-29j','3fnp'],
            185=>['b2-30y','kwwv'],
            186=>['b2-31t','thr5'],
            187=>['b2-32p','7b2s'],
            188=>['b2-33y','y5u3'],
            189=>['b2-34a','u8rk'],
            190=>['b2-35c','ipps'],
            191=>['b2-36e','mer2'],
            192=>['b2-37v','thux'],
            193=>['b2-38p','24fn'],
            194=>['b2-39u','k383'],
            195=>['b2-40t','pz3h'],
            196=>['b2-41k','arts'],
            197=>['b2-42e','7sjp'],
            198=>['b2-43r','f84y'],
            199=>['b2-44e','mbky'],
            200=>['b2-45r','4rhf']
        ];

    }
}
