<?php

use Illuminate\Database\Seeder;

class ChallengeUserUnitAverageMarksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        //DB::statement('SET CONSTRAINTS ALL DEFERRED;');
//        \App\ChallengeUserUnitAverageMark::truncate();
        //DB::statement('SET CONSTRAINTS ALL IMMEDIATE;');

        $faker = Faker\Factory::create("ja_JP");

        $units = \App\Unit::all();

        foreach ($units as $un) {
            for ($i = 0; $i < 10 ; $i++){
                $challuser = \App\ChallengeUserUnitAverageMark::create([
                    "unit_id" => $un->id,
                    "mark" => 10,
                    "challenge_user_id" => 1,
                    "marking_log_id"=>1
                ]);
                $challuser->save();
            }
        }
    }
}
