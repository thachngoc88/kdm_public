<?php

use Illuminate\Database\Seeder;
use \App\Record;

class RecordsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //delete all data.
        //DB::statement('SET CONSTRAINTS ALL DEFERRED;');
//        Record::truncate();
        //DB::statement('SET CONSTRAINTS ALL IMMEDIATE;');

        $faker = Faker\Factory::create("ja_JP");

        $challengeUsers = \App\ChallengeUser::all();
        foreach ($challengeUsers as $challengeUser) {
            $questions = \App\Question::all();
            foreach ($questions as $q) {
                if($q->workbook->unit->curriculum->grade->number == $challengeUser->klass->grade->number) {
                    $record = Record::create([
                        "challenge_user_id" => $challengeUser->id,
                        "question_id" => $q->id,
                        "record" => $faker->numberBetween(1, 2),
                    ]);
                    $record->save();
                }
            }
        }

    }
}
