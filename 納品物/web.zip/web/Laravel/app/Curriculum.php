<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Curriculum extends Model
{
    protected $table = "curriculums";

    public function grade() {
        return $this->belongsTo('App\Grade');
    }

    public function subject() {
        return $this->belongsTo('App\Subject');
    }

    public function units() {
        return $this->hasMany('App\Unit')->orderBy('number');
    }

    public function timings() {
        return $this->hasMany('App\Timing');
    }

    /**
     *
     * @return string
     */
    public function getDisplayTitleAttribute()
    {
        return $this->grade->number . "年 " . $this->subject->name;
    }
}
