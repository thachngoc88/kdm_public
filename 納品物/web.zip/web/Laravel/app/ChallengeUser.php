<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChallengeUser extends Model
{
    //
    public $table = "challenge_users";

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function klass(){
        return $this->belongsTo('App\Klass', 'class_id');
    }

    public function records(){
        return $this->hasMany('App\Record');
    }

//    /**
//     * Grade number of a challenge user
//     *
//     * @param \Illuminate\Database\Eloquent\Builder $query
//     * @return \Illuminate\Database\Eloquent\Builder
//     */
//    public function scopeGradeNumber($query){
//        return $query
//            ->join('classes as C','challenge_users.class_id','=', 'C.id')
//            ->join('grades as G','C.grade_id','=', 'G.id')
//            ->first(['number']);
//    }

}
