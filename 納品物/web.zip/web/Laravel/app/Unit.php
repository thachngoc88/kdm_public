<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    public $table = "units";

    public function curriculum() {
        return $this->belongsTo('App\Curriculum');
    }

    public function workbooks() {
        return $this->hasMany('App\Workbook')->orderBy('number');
    }
}
