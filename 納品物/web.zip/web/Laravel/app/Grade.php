<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grade extends Model
{

    public $table = "grades";

    public function curriculums(){
        return $this->hasMany('App\Curriculum');
    }
    public function classes(){
        return $this->hasMany('App\Klass');
    }
    public function subjects(){
        return $this->belongsToMany('App\Subject','curriculums');
    }


}
