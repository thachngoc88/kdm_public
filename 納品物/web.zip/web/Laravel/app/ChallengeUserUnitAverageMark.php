<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChallengeUserUnitAverageMark extends Model
{
    //
    protected $table = "challenge_user_unit_average_marks";
    public function unit(){
        return $this->belongsTo('App\Unit');
    }

    public function challenge_user(){
        return $this->belongsTo('App\ChallengeUser');
    }
    public function marking_log(){
        return $this->belongsTo('App\MarkingLog');
    }
}
