<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplement extends Model
{
    //
    public $table = "supplements";

    public function workbook() {
        return $this->belongsTo('App\Workbook');
    }
    public function challenge_questions_supplenments() {
        return $this->hasMany('App\ChallengeQuestionSupplement');
    }
}
