<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    //
    public $table = "cities";

    public function prefecture(){
        return $this->belongsTo('App\Curriculum');
    }

    public function schools(){
        return $this->hasMany('App\School');
    }

    public function cityUsers(){
        return $this->hasMany('App\CityUser');
    }
}
