<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchoolPassingRate extends Model
{
    //
    protected $table = "school_passing_rates";

    protected $fillable = [
        'school_id', 'workbook_id',
    ];

    public function school(){
        return $this->belongsTo('App\School');
    }

    public function workbook(){
        return $this->belongsTo('App\Workbook');
    }

    public function marking_log(){
        return $this->belongsTo('App\MarkingLog');
    }
}
