<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Challenge extends Model
{
    //
    public $table = "challenges";

    public function workbook() {
        return $this->belongsTo('App\Workbook');
    }
    public function challenge_questions_supplements() {
        return $this->hasMany('App\ChallengeQuestionSupplement');
    }
}
