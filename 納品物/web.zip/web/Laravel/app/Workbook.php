<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Workbook extends Model
{
    //
    public $table = "workbooks";

    public function unit() {
        return $this->belongsTo('App\Unit');
    }

    public function challenge() {
        return $this->hasOne('App\Challenge');
    }

    public function supplement() {
        return $this->hasOne('App\Supplement');
    }

    public function questions() {
        return $this->hasMany('App\Question');
    }

}
