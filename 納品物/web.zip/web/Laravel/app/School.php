<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{

    public $table = "schools";

    public function city(){
        return $this->belongsTo('App\City');
    }

    public function classes(){
        return $this->hasMany('App\Klass');
    }

    public function schoolUsers(){
        return $this->hasMany('App\SchoolUser');
    }

    public function users()
    {
        return $this->belongsToMany('App\User','school_users');
    }
}
