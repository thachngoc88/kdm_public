<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrefectureUser extends Model
{
    public $table = "prefecture_users";

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function prefecture(){
        return $this->belongsTo('App\Prefecture');
    }
}
