<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Record extends Model
{
    //
    public $table = "records";

    protected $fillable = ['challenge_user_id', 'question_id', 'record'];

    public function question() {
        return $this->belongsTo('App\Question');
    }

    public function challengeUser() {
        return $this->belongsTo('App\ChallengeUser');
    }
}
