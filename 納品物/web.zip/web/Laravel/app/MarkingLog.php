<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarkingLog extends Model
{
    //
    protected $table = "marking_logs";
    public function marks(){
        return $this->hasMany('App\Mark');
    }

    public function challenge_user_unit_average_marks(){
        return $this->hasMany('App\ChallengeUserUnitAverageMark');
    }
    public function class_passing_rates(){
        return $this->hasMany('App\ClassPassingRate');
    }
    public function class_unit_passing_rates(){
        return $this->hasMany('App\ClassUnitPassingRate');
    }
    public function class_curriculum_passing_rates(){
        return $this->hasMany('App\ClassCurriculumPassingRate');
    }
}
