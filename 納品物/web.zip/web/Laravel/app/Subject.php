<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    //
    public $table = "subjects";

    public function curriculums(){
        return $this->hasMany('App\Curriculum');
    }
}
