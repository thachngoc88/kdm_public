<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'login_id', 'password', 'enabled',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public  function  cities(){
        return $this->belongsToMany('App\City','city_users');
    }

    public  function  schools(){
        return $this->belongsToMany('App\School','school_users');
    }

    public  function  classes(){
        return $this->belongsToMany('App\Klass','challenge_users','user_id','class_id');
    }
}
