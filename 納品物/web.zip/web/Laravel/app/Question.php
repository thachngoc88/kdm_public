<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    //
    public $table = "questions";

    public function workbook() {
        return $this->belongsTo('App\Workbook');
    }

    public function answer() {
        return $this->belongsTo('App\Answer');
    }
    public function records(){
        return $this->hasMany('App\Record','question_id','id');
    }
}
