<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Condition extends Model
{
    //
    protected $table = "conditions";

    public function messages(){
        return $this->hasMany('App\Message');
    }
    public function timing(){
        return $this->belongsTo('App\Timing');
}
}
