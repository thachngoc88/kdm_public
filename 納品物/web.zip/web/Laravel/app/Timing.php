<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Timing extends Model
{
    //
    protected $table ="timings";

    public function  conditions(){
        return $this->hasMany('App\Condition');
    }
    public  function  subject(){
        return $this->belongsTo('App\Subject');
    }
}
